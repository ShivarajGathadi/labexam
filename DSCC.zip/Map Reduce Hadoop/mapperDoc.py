#su
#password- cloudera
#cd workspace
#mkdir inputfiles
#mount -t vboxsf Input /home/cloudera/workspace/InputFiles
#(minimize)



#ls
#cd workspace
#ls
#cd inputfiles
#ls

		
#sudo nano mapperDoc.py
#!/usr/bin/env python
import sys
for line in sys.stdin:
	line=line.strip()
	words=line.split()
	for word in words:
		print("%s\t%s" %(word,"1"))
#ctrl+x 
#y
#enter
#cat doc.txt|./mapperDoc.py