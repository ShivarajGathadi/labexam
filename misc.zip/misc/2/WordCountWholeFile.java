import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class WordCountWholeFile{
  public static class WordMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
    private static final Text outputKey = new Text("TotalWords");
    private static final IntWritable one = new IntWritable(1);
    public void map(LongWritable key,Text value,Context context) throws IOException,InterruptedException{
      String[] words = value.toString().split("\\s+");
      for(String word : words){
        if(!word.isEmpty()){
          context.write(outputKey,one);
        }
      }
    }
  }
  public static class SumReducer extends Reducer<Text,IntWritable,Text,IntWritable>{
    public void reducer(Text key,Iterable<IntWritable> values,Context context) throws IOException,InterruptedException{
      int sum=0;
      for(IntWritable val : values){
        sum+=val.get();
      }
      context.write(key,new IntWritable(sum));
    }
  }
  public static void main(String[] args) throws Exception{
    Job job = Job.getInstance(new Configuration(),"Count Total Words");
    job.setJarByClass(WordCountWholeFile.class);
    job.setMapperClass(WordMapper.class);
    job.setReducerClass(SumReducer.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job,new Path(args[0]));
    FileOutputFormat.setOutputPath(job,new Path(args[1]));
    System.exit(job.waitForCompletion(true)?0:1);
  }
}
