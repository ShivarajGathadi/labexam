import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class AvgTemp {

    public static class TempMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
        private final Text city = new Text();
        private final IntWritable temp = new IntWritable();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            // Expecting lines like: CityName,25
            String line = value.toString().trim();
            if (line.isEmpty()) return;

            String[] parts = line.split(",", -1);
            if (parts.length == 2) {
                String cityName = parts[0].trim();
                String tempStr = parts[1].trim();
                if (!cityName.isEmpty() && !tempStr.isEmpty()) {
                    try {
                        int t = Integer.parseInt(tempStr);
                        city.set(cityName);
                        temp.set(t);
                        context.write(city, temp);
                    } catch (NumberFormatException e) {
                        // skip malformed temperature values
                    }
                }
            }
        }
    }

    public static class TempReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {
        private final DoubleWritable result = new DoubleWritable();

        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int sum = 0;
            int count = 0;
            for (IntWritable val : values) {
                sum += val.get();
                count++;
            }
            if (count > 0) {
                double average = (double) sum / count;
                result.set(average);
                context.write(key, result);
            }
            // if count == 0, nothing to write
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: AvgTemp <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Average Temperature");
        job.setJarByClass(AvgTemp.class);

        job.setMapperClass(TempMapper.class);
        job.setReducerClass(TempReducer.class);

        // mapper output types
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);

        // final output types
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}

