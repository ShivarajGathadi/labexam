import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MaxTemperature {

    public static class TempMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
        private final Text city = new Text();
        private final IntWritable temperature = new IntWritable();

        @Override
        public void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {

            // Expecting lines like: CityName,25
            String line = value.toString().trim();
            if (line.isEmpty()) return;

            String[] parts = line.split(",");
            if (parts.length == 2) {
                String cityName = parts[0].trim();
                String tempStr = parts[1].trim();
                try {
                    int temp = Integer.parseInt(tempStr);
                    city.set(cityName);
                    temperature.set(temp);
                    context.write(city, temperature);
                } catch (NumberFormatException e) {
                    // Ignore non-numeric temperature values
                }
            }
        }
    }

    public static class MaxTempReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            int maxTemp = Integer.MIN_VALUE;
            boolean found = false;

            for (IntWritable val : values) {
                if (val == null) continue;
                int t = val.get();
                if (!found || t > maxTemp) {
                    maxTemp = t;
                    found = true;
                }
            }

            // Only write if we found at least one numeric temperature
            if (found) {
                context.write(key, new IntWritable(maxTemp));
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: MaxTemperature <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Maximum Temperature Per City");
        job.setJarByClass(MaxTemperature.class);

        job.setMapperClass(TempMapper.class);
        job.setReducerClass(MaxTempReducer.class);

        // Map output types
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);

        // Final output types
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
