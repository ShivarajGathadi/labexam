const summ = require("./custom.js");
console.log(summ(10,20));