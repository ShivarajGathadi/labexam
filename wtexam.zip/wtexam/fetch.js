const mongo=require("mongodb")
const mclient=mongo.MongoClient;
let url="mongodb://localhost:27017"
async function connectDB()
{
 try {
 const conn=await mclient.connect(url)
 console.log("Connection to MongoDB success")
 const c=conn.db("test");
 console.log("Connected to test database")
 const std=await c.collection("student")
 console.log("Student collection opened...")
 const data=await std.find({}).toArray();
 console.log("Fetching student records\n=======")
 console.log(data)
 console.log("Number of records fetched="+data.length)
 conn.close();
 }catch(err)
 {
 console.log("Error="+err)
 }
}
connectDB();
