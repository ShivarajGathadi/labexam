const fs= require('fs');
fs.writeFileSync("text.txt","hey hello");
const dataa = fs.readFileSync("text.txt","utf-8")
console.log(dataa);