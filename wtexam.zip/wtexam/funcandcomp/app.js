import logo from './logo.svg';
import './App.css';
import Any from './func'
import Abcdef from './classs'

function App() {
  return (
    <div className="App">
        <h1>hey</h1>
        <Any/>
        <Abcdef/>
    </div>
  );
}

export default App;
