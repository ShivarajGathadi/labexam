import { Component } from "react";
class Abcdef extends Component{
    render(){
        return(<div>
            <h1>hello from comp</h1>
        </div>);
    }
}
export default Abcdef;