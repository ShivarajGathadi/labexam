function Any(props){
    return (<div>
        <h1>Any</h1>
    </div>);
}

export default Any;