import './App.css';
import Arithmetic from './eventexamples/Arithmetic';
function App() {
return (
<div className="App">
<Arithmetic/>
</div>
);
}
export default App;