import logo from './logo.svg';
import './App.css';
import Any from './func'
import Abcdef from './classs'

function App() {
  return (
    <div className="App">
        <h1>hey</h1>
        <Any id={12} />
        <Abcdef/>
    </div>
  );
}

export default App;
