function Any(props){
    return (<div>
        <h1>Any</h1>
        <h1>{props.id}</h1>
    </div>);
}

export default Any;