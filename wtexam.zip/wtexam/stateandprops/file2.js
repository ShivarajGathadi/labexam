import { Component } from "react";
class Abcdef extends Component{
    constructor(props){
        super(props);
        this.state={"id":13}
    }
    change=()=>{
        this.setState({"id":122})
    }
    render(){
        return(<div>
            <h1>hello</h1>
            <h1>id={this.state.id}</h1>
            <button onClick={this.change}>changeeee</button>
        </div>);
    }
}
export default Abcdef;