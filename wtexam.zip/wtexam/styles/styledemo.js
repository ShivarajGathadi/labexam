import styles1 from "./second.css"
import "./first.css"
function Abcd(){
    return(
        <div>
    <h1 style={{color:"red",fontSize:"30px"}}>this is inline css</h1>
    <p>external css</p>
    <h1 className={styles1.rules1}>external module css</h1>
    </div>
    );
}

export default Abcd;